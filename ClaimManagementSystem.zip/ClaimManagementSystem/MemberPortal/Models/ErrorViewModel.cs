using System;

namespace MemberPortal.Models
{
    public class ErrorViewModel
    {
        public string ErrorMessage { get; set; }

      
    }
}
